package com.example.bluetoothisim;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private BluetoothAdapter adapter;
    private final List<BluetoothDevice> devices = new ArrayList<>();
    private ArrayAdapter<String> listAdapter;
    private TextView selectedLabel;
    private EditText nameInput;
    private BluetoothDevice selected;
    private static final int REQUEST_PERMISSIONS = 10;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = manager.getAdapter();
        buildUi();
        if (adapter == null) { toast("Bu telefonda Bluetooth bulunamadı."); return; }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, REQUEST_PERMISSIONS);
        } else loadDevices();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24, 28, 24, 20); root.setBackgroundColor(0xFFF7F8FA);
        TextView title = new TextView(this); title.setText("Bluetooth İsim Değiştirici"); title.setTextSize(23); title.setTextColor(0xFF172033); title.setGravity(Gravity.CENTER); title.setPadding(0, 8, 0, 18); root.addView(title);
        TextView info = new TextView(this); info.setText("Önceden eşleştirilmiş cihazlardan birini seçin."); info.setTextSize(14); info.setTextColor(0xFF596579); root.addView(info);
        ListView list = new ListView(this); listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>()); list.setAdapter(listAdapter); root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        selectedLabel = new TextView(this); selectedLabel.setText("Seçili cihaz: Yok"); selectedLabel.setTextColor(0xFF172033); selectedLabel.setPadding(0, 12, 0, 8); root.addView(selectedLabel);
        nameInput = new EditText(this); nameInput.setSingleLine(true); nameInput.setHint("Yeni hoparlör adı"); root.addView(nameInput);
        Button rename = new Button(this); rename.setText("Adı değiştir"); root.addView(rename);
        Button refresh = new Button(this); refresh.setText("Listeyi yenile"); root.addView(refresh);
        setContentView(root);
        list.setOnItemClickListener((p,v,pos,id) -> { selected = devices.get(pos); try { selectedLabel.setText("Seçili cihaz: " + safeName(selected)); nameInput.setText(safeName(selected)); } catch (SecurityException e) { toast("Bluetooth izni gerekli."); } });
        rename.setOnClickListener(v -> renameDevice());
        refresh.setOnClickListener(v -> loadDevices());
    }

    private String safeName(BluetoothDevice d) { String n = d.getName(); return n == null ? "İsimsiz cihaz" : n; }
    private void loadDevices() {
        if (adapter == null) return;
        try {
            devices.clear(); listAdapter.clear();
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            for (BluetoothDevice d : bonded) { devices.add(d); listAdapter.add(safeName(d) + "\n" + d.getAddress()); }
            if (devices.isEmpty()) toast("Eşleştirilmiş cihaz bulunamadı. Önce telefonun Bluetooth ayarlarından hoparlörü eşleştirin.");
        } catch (SecurityException e) { toast("Bluetooth izni verilmedi."); }
    }
    private void renameDevice() {
        if (selected == null) { toast("Önce listeden bir cihaz seçin."); return; }
        String newName = nameInput.getText().toString().trim();
        if (newName.isEmpty()) { nameInput.setError("Bir isim girin"); return; }
        if (Build.VERSION.SDK_INT < 30) { toast("Bu Android sürümünde uygulama içinden cihaz takma adı değiştirilemiyor."); return; }
        try {
            boolean ok = selected.setAlias(newName);
            if (ok) { selectedLabel.setText("Seçili cihaz: " + newName); toast("Telefonun Bluetooth listesindeki ad güncellendi."); loadDevices(); }
            else toast("Android bu cihazın adını değiştirmeye izin vermedi.");
        } catch (SecurityException e) { toast("İzin veya sistem kısıtlaması nedeniyle ad değiştirilemedi."); }
          catch (Exception e) { toast("Ad değiştirilemedi: " + e.getMessage()); }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_PERMISSIONS) loadDevices();
    }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
